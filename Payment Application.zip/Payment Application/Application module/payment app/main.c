#pragma warning(disable : 4996)
#include<stdio.h>
#include "../payment app/Application/app.h"

int main() {

	appStart();
}